import os
import json
import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict
import requests
from flask import Flask, jsonify
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from dotenv import load_dotenv
import threading

# Загружаем переменные окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Конфигурация
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
API_URL = os.getenv('API_URL', 'http://localhost:8080')
PORT = int(os.getenv('PORT', 10000))

# Создаем Flask приложение для health checks
app = Flask(__name__)


@app.route('/')
def home():
    return jsonify({
        'status': 'running',
        'bot': 'Minecraft Telegram Bot',
        'time': datetime.now().isoformat()
    })


@app.route('/health')
def health():
    return jsonify({'status': 'healthy'})


class MinecraftBot:
    def __init__(self):
        self.api_keys: Dict[int, str] = {}
        self.usernames: Dict[int, str] = {}
        self.is_op: Dict[int, bool] = {}

    async def api_request(self, endpoint: str, method: str = 'GET', data: Optional[dict] = None,
                          api_key: Optional[str] = None) -> Optional[dict]:
        """Выполняет запрос к API плагина"""
        url = f"{API_URL}{endpoint}"
        headers = {}

        if api_key:
            headers['Authorization'] = f"Bearer {api_key}"

        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data, timeout=10)
            else:
                return None

            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"API Error: {response.status_code} - {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {e}")
            return None

    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /start"""
        await update.message.reply_text(
            "👋 Привет! Я бот для управления Minecraft сервером.\n\n"
            "🔐 Для начала авторизуйтесь: /login <ваш_ник>\n"
            "📊 Проверить онлайн: /online\n"
            "❓ Все команды: /help"
        )

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /help"""
        chat_id = update.effective_chat.id
        is_auth = chat_id in self.api_keys
        is_admin = self.is_op.get(chat_id, False)

        message = (
            "📚 <b>Доступные команды:</b>\n"
            "━━━━━━━━━━━━━━━\n"
            "/start - Начать работу\n"
            "/login <ник> - Авторизация\n"
            "/online - Проверить онлайн\n"
            "/help - Показать это сообщение"
        )

        if is_auth and is_admin:
            message += (
                "\n\n🛡 <b>Админ команды:</b>\n"
                "/say <сообщение> - Отправить сообщение в чат\n"
                "/mute <ник> <время> <причина> - Замутить игрока\n"
                "/ban <ник> <причина> - Забанить игрока\n"
                "/kick <ник> <причина> - Кикнуть игрока\n"
                "/java <команда> - Выполнить любую команду"
            )

        await update.message.reply_text(message, parse_mode='HTML')

    async def login_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /login"""
        if not context.args:
            await update.message.reply_text(
                "❌ Используйте: /login <ваш_никнейм>\n"
                "Пример: /login Steve"
            )
            return

        nickname = context.args[0]
        chat_id = update.effective_chat.id

        # Запрос на авторизацию
        result = await self.api_request(
            '/api/auth',
            method='POST',
            data={'nickname': nickname}
        )

        if result and result.get('success'):
            self.api_keys[chat_id] = result['api_key']
            self.usernames[chat_id] = result['nickname']
            self.is_op[chat_id] = result.get('is_op', False)

            await update.message.reply_text(
                f"✅ Вы успешно авторизованы как {result['nickname']}!\n"
                f"Статус OP: {'Да ⭐' if result.get('is_op') else 'Нет'}"
            )
        else:
            await update.message.reply_text(
                "❌ Игрок не найден на сервере!\n"
                "Убедитесь, что вы заходили на сервер хотя бы раз."
            )

    async def online_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /online"""
        chat_id = update.effective_chat.id
        api_key = self.api_keys.get(chat_id)

        # Получаем информацию об онлайне
        if api_key:
            result = await self.api_request('/api/online', api_key=api_key)
            players_result = await self.api_request('/api/players', api_key=api_key)
        else:
            result = await self.api_request('/api/online')
            players_result = None

        if result:
            online = result.get('online', 0)
            admins = result.get('admins', 0)
            max_players = result.get('max_players', 0)

            players_list = ""
            if players_result and 'players' in players_result:
                players = players_result['players']
                if players:
                    players_list = "\n\n📋 <b>Игроки онлайн:</b>\n"
                    for player in players:
                        op_mark = " ⭐" if player.get('is_op') else ""
                        players_list += f"• {player['name']}{op_mark} (HP: {player['health']:.0f})\n"

            message = (
                f"🎮 <b>Проверка онлайна</b>\n"
                f"━━━━━━━━━━━━━━━\n"
                f"👥 <b>Всего:</b> {online}/{max_players}\n"
                f"⭐ <b>Из админов:</b> {admins}\n"
                f"⏰ <b>Время:</b> {datetime.now().strftime('%H:%M:%S')}"
                f"{players_list}"
            )

            await update.message.reply_text(message, parse_mode='HTML')
        else:
            await update.message.reply_text(
                "❌ Не удалось получить информацию с сервера.\n"
                "Сервер может быть выключен или API недоступен."
            )

    async def say_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /say"""
        chat_id = update.effective_chat.id

        if not self.check_auth(chat_id):
            await update.message.reply_text("❌ Вы не авторизованы! Используйте /login <ник>")
            return

        if not self.check_op(chat_id):
            await update.message.reply_text("❌ У вас нет прав администратора!")
            return

        if not context.args:
            await update.message.reply_text("❌ Используйте: /say <сообщение>")
            return

        message = ' '.join(context.args)
        sender = self.usernames[chat_id]

        result = await self.api_request(
            '/api/broadcast',
            method='POST',
            data={'message': message, 'sender': f"{sender} (TG)"},
            api_key=self.api_keys[chat_id]
        )

        if result and result.get('success'):
            await update.message.reply_text("✅ Сообщение отправлено в игру!")
        else:
            await update.message.reply_text("❌ Ошибка отправки сообщения")

    async def mute_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /mute"""
        chat_id = update.effective_chat.id

        if not self.check_auth(chat_id):
            await update.message.reply_text("❌ Вы не авторизованы! Используйте /login <ник>")
            return

        if not self.check_op(chat_id):
            await update.message.reply_text("❌ У вас нет прав администратора!")
            return

        if len(context.args) < 2:
            await update.message.reply_text(
                "❌ Используйте: /mute <ник> <время> <причина>\n"
                "Пример: /mute Steve 10m Нарушение правил\n"
                "Время: 10s, 30m, 5h, 0 = навсегда"
            )
            return

        target = context.args[0]
        time_str = context.args[1]
        reason = ' '.join(context.args[2:]) if len(context.args) > 2 else "Не указана"

        seconds = self.parse_time(time_str)
        command = f"mute {target} {seconds}s {reason}"

        result = await self.api_request(
            '/api/command',
            method='POST',
            data={'command': command, 'type': 'console'},
            api_key=self.api_keys[chat_id]
        )

        if result and result.get('success'):
            time_display = self.format_time(seconds)
            await update.message.reply_text(
                f"✅ Игрок <b>{target}</b> замучен на <b>{time_display}</b>\n"
                f"Причина: {reason}",
                parse_mode='HTML'
            )
        else:
            await update.message.reply_text("❌ Ошибка выполнения команды")

    async def ban_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /ban"""
        chat_id = update.effective_chat.id

        if not self.check_auth(chat_id):
            await update.message.reply_text("❌ Вы не авторизованы! Используйте /login <ник>")
            return

        if not self.check_op(chat_id):
            await update.message.reply_text("❌ У вас нет прав администратора!")
            return

        if len(context.args) < 1:
            await update.message.reply_text(
                "❌ Используйте: /ban <ник> <причина>\n"
                "Пример: /ban Steve Читерство"
            )
            return

        target = context.args[0]
        reason = ' '.join(context.args[1:]) if len(context.args) > 1 else "Не указана"

        command = f"ban {target} {reason}"

        result = await self.api_request(
            '/api/command',
            method='POST',
            data={'command': command, 'type': 'console'},
            api_key=self.api_keys[chat_id]
        )

        if result and result.get('success'):
            await update.message.reply_text(
                f"✅ Игрок <b>{target}</b> забанен навсегда\n"
                f"Причина: {reason}",
                parse_mode='HTML'
            )
        else:
            await update.message.reply_text("❌ Ошибка выполнения команды")

    async def kick_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /kick"""
        chat_id = update.effective_chat.id

        if not self.check_auth(chat_id):
            await update.message.reply_text("❌ Вы не авторизованы! Используйте /login <ник>")
            return

        if not self.check_op(chat_id):
            await update.message.reply_text("❌ У вас нет прав администратора!")
            return

        if len(context.args) < 1:
            await update.message.reply_text(
                "❌ Используйте: /kick <ник> <причина>\n"
                "Пример: /kick Steve Нарушение"
            )
            return

        target = context.args[0]
        reason = ' '.join(context.args[1:]) if len(context.args) > 1 else "Не указана"

        command = f"kick {target} {reason}"

        result = await self.api_request(
            '/api/command',
            method='POST',
            data={'command': command, 'type': 'console'},
            api_key=self.api_keys[chat_id]
        )

        if result and result.get('success'):
            await update.message.reply_text(
                f"✅ Игрок <b>{target}</b> кикнут\n"
                f"Причина: {reason}",
                parse_mode='HTML'
            )
        else:
            await update.message.reply_text("❌ Ошибка выполнения команды")

    async def java_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик команды /java"""
        chat_id = update.effective_chat.id

        if not self.check_auth(chat_id):
            await update.message.reply_text("❌ Вы не авторизованы! Используйте /login <ник>")
            return

        if not self.check_op(chat_id):
            await update.message.reply_text("❌ У вас нет прав администратора!")
            return

        if not context.args:
            await update.message.reply_text(
                "❌ Используйте: /java <команда>\n"
                "Пример: /java effect clear Steve\n"
                "Пример: /java restart"
            )
            return

        command = ' '.join(context.args)

        result = await self.api_request(
            '/api/command',
            method='POST',
            data={'command': command, 'type': 'console'},
            api_key=self.api_keys[chat_id]
        )

        if result and result.get('success'):
            await update.message.reply_text(
                f"✅ Команда выполнена:\n"
                f"<code>{command}</code>",
                parse_mode='HTML'
            )
        else:
            await update.message.reply_text("❌ Ошибка выполнения команды")

    def check_auth(self, chat_id: int) -> bool:
        """Проверка авторизации"""
        return chat_id in self.api_keys

    def check_op(self, chat_id: int) -> bool:
        """Проверка OP статуса"""
        return self.is_op.get(chat_id, False)

    def parse_time(self, time_str: str) -> int:
        """Парсинг времени в секунды"""
        if time_str == "0":
            return 0

        try:
            unit = time_str[-1].lower()
            value = int(time_str[:-1])

            if unit == 's':
                return value
            elif unit == 'm':
                return value * 60
            elif unit == 'h':
                return value * 3600
            elif unit == 'd':
                return value * 86400
            else:
                return int(time_str)
        except:
            return 600

    def format_time(self, seconds: int) -> str:
        """Форматирование времени"""
        if seconds == 0:
            return "навсегда"
        elif seconds < 60:
            return f"{seconds} сек"
        elif seconds < 3600:
            return f"{seconds // 60} мин"
        elif seconds < 86400:
            return f"{seconds // 3600} час(ов)"
        else:
            return f"{seconds // 86400} дн(ей)"


def run_flask():
    """Запуск Flask сервера"""
    app.run(host='0.0.0.0', port=PORT)


def main():
    """Запуск бота"""
    if not TELEGRAM_TOKEN:
        logger.error("TELEGRAM_TOKEN не установлен!")
        return

    # Запускаем Flask в отдельном потоке
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()

    bot = MinecraftBot()
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    # Регистрируем обработчики
    application.add_handler(CommandHandler("start", bot.start_command))
    application.add_handler(CommandHandler("help", bot.help_command))
    application.add_handler(CommandHandler("login", bot.login_command))
    application.add_handler(CommandHandler("online", bot.online_command))
    application.add_handler(CommandHandler("say", bot.say_command))
    application.add_handler(CommandHandler("mute", bot.mute_command))
    application.add_handler(CommandHandler("ban", bot.ban_command))
    application.add_handler(CommandHandler("kick", bot.kick_command))
    application.add_handler(CommandHandler("java", bot.java_command))

    logger.info("Бот запущен!")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()